
Face Mask Detection - v2 2022-02-05 12:08pm
==============================

This dataset was exported via roboflow.ai on February 6, 2022 at 12:33 PM GMT

It includes 853 images.
Mask are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


